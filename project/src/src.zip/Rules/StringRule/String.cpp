#include "stdafx.h"
#include "String.h"

size_t String::index = 0;