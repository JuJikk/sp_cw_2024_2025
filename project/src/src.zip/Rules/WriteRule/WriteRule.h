#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeWriteRule(std::shared_ptr<Controller> controller);