#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeAssignmentRule(std::shared_ptr<Controller> controller);