#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeReadRule(std::shared_ptr<Controller> controller);