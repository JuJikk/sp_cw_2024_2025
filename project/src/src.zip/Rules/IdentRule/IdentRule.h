#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeIdentRule(std::shared_ptr<Controller> controller);