#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeFor(std::shared_ptr<Controller> controller);