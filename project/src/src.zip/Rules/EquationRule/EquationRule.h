#pragma once
#include "stdafx.h"
#include "Controller.h"

BackusRulePtr MakeEquationRule(std::shared_ptr<Controller> controller);